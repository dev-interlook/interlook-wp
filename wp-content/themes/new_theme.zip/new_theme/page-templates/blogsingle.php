<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since Twenty Seventeen 1.0
 * @version 1.0
 */

get_header(); ?>
<div class="sections" style="background:url(<?php the_field( 'cover' ); ?>); background-repeat: no-repeat;background-size: 100% auto;background-position-y: -250px;"">
        <div class="container">
            <div class="pages-title">
                <h1>Eksonindo <br> <span><?php the_title(); ?></span></h1>
                <p><a href="/">Home</a> &nbsp; > <a href="/blog/">Blog</a> &nbsp; > &nbsp; <a href="#"><?php the_title(); ?></a></p>
            </div>
        </div>  
    </div>
    
    
  
    <!-- CONTENT START -->
    <section>
        <div class="container">
            <div class="row">
              <!-- SINGLE POST CONTENT START -->
              <div class="col-lg-8 col-xl-9">
                <figure class="post-image"><img src="<?php the_field( 'cover' ); ?>" alt=""></figure>
                <div class="post-content">
                    <h2><?php the_tItle(); ?></h2>
                    <?php the_field( 'content' ); ?>
                </div>
                  
                <!-- COMMENTS START -->
                <!-- <div class="comments">
                    <h3>Comments (3)</h3>
                    <hr class="comments">
                    <div class="comment-box">
                        <figure class="user-avatar"><img src="img/images/avatar1.jpg" alt=""></figure>
                        <div class="comment-details">
                            <h5>Lori Thomas</h5>
                            <p class="comment-date">January 9, 2019</p>
                            <p class="comment">Reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it.</p>
                            <div class="comment-interaction">
                                <div class="vote-up"><a href="#"><i class="fas fa-angle-up"></i></a></div>
                                <div class="vote-down"><a href="#"><i class="fas fa-angle-down"></i></a></div>
                                <div class="replay-box"><a href="#"><i class="fas fa-reply"></i></a></div>
                            </div>
                        </div>
                    </div>
                    <hr class="comments">
                    <div class="comment-box">
                        <figure class="user-avatar"><img src="img/images/avatar2.jpg" alt=""></figure>
                        <div class="comment-details">
                            <h5>Robert Smith</h5>
                            <p class="comment-date">January 6, 2019</p>
                            <p class="comment">Reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it.</p>
                            <div class="comment-interaction">
                                <div class="vote-up"><a href="#"><i class="fas fa-angle-up"></i></a></div>
                                <div class="vote-down"><a href="#"><i class="fas fa-angle-down"></i></a></div>
                                <div class="replay-box"><a href="#"><i class="fas fa-reply"></i></a></div>
                            </div>
                        </div>
                    </div>
                    <hr class="comments">
                    <div class="comment-box">
                        <figure class="user-avatar"><img src="img/images/avatar3.jpg" alt=""></figure>
                        <div class="comment-details">
                            <h5>Joe Luke</h5>
                            <p class="comment-date">January 3, 2019</p>
                            <p class="comment">Reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it.</p>
                            <div class="comment-interaction">
                                <div class="vote-up"><a href="#"><i class="fas fa-angle-up"></i></a></div>
                                <div class="vote-down"><a href="#"><i class="fas fa-angle-down"></i></a></div>
                                <div class="replay-box"><a href="#"><i class="fas fa-reply"></i></a></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="comment-form">
                    <h3>Leave a Comment</h3>
                    <hr class="comments">
                    <form>
                      <div class="form-row">
                        <div class="col-md-6">
                          <input type="text" class="form-control customize" placeholder="First name">
                        </div>
                        <div class="col-md-6">
                          <input type="email" class="form-control customize" id="inputEmail3" placeholder="Email">
                        </div>
                        <div class="col-md-12">
                          <input type="text" class="form-control customize" placeholder="Your website">
                        </div>
                        <div class="col-md-12">
                          <textarea id="form_message" name="message" class="form-control customize" placeholder="Your message" rows="6" required="required" data-error="Please,leave us a message."></textarea>
                        </div>
                      </div>
                    </form>
                    <div class="btn-comments"><a class="btn btn-custom" href="#" role="button">SEND COMMENT</a></div>
                </div> -->
                <!-- COMMENTS END -->
              </div>
              <!-- SINGLE POST CONTENT END -->
              
              <!-- SINGLE POST SIDEBAR START -->
              <div class="col-lg-4 col-xl-3 space-break">
                  <aside>
                    <div class="form-group blog-search">
                    <form action="http://eksonindo.test/search/" method="post">
                        <span class="fa fa-search form-control-feedback"></span>
                        <input type="text" name="search" class="form-control" placeholder="Search">
						</form>
                      </div>
                      <div class="aside-list-group">
                          <h4>Categorie</h4>
						  
                        <ul class="list-group list-group-flush">
						<?php
                $no = 1;
                $args = array(
                    'child_of'=>2,
                    'hide_empty'=> 0,
                    'orderby' => 'name',
                    'order' => 'ASC'
                );
                $categories = get_categories($args);
                foreach($categories as $category) { 
                ?>
                <li class="list-group-item"><a href="/category/blog/<?php echo $category->slug ; ?>"><?php echo $category->name ; ?></a>
                            <span class="badge badge-primary badge-pill"><?php echo $category->category_count; ?></span>
                          </li>
                <?php } ?>
							

                        </ul>
                      </div>
                      <div class="aside-related-posts">
                        <h4>Related Posts</h4>
                        <div class="aside-related-posts">
						
<?php $latest = new WP_Query(array('cat' => 2 , 'showposts' => 5));?>
<?php if(have_posts()) :while($latest->have_posts()) : $latest->the_post();?>
                          <div class="media">
                              <a href="<?php the_permalink() ?>"><img src="<?php the_field( 'cover' ); ?>" class="mr-3" alt="..."></a> 
                              <div class="media-body">
                                <h5 class="mt-0"><a href="#"><?php the_title(); ?></a></h5>
                                <p><?php echo get_the_date(); ?></p>
                              </div>
                          </div>

						  <?php endwhile; endif; ?>
                       </div>
                      </div>
                      <div class="aside-tags">
                        <h4>Tags</h4>
						<?php 
$tags = get_tags(array(
  'hide_empty' => false
));
foreach ($tags as $tag) { ?>
                        <a class="btn btn-tags" href="#" role="button"><?php echo $tag->name; ?></a>
			<?php } ?>
                      </div> 
                  </aside>
              </div>
              <!-- SINGLE POST SIDEBAR END -->
            </div>
        </div>

    </section>
	<style>

a.btn.btn-tags {
    margin-bottom: 5px;
}

	</style>

<?php
get_footer();
