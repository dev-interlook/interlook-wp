<?php



/**



 Template Name: bodypack



 */



?>

<?php get_header();?>
<?php if (have_posts()) : while ( have_posts() ) : the_post(); ?>
<div class="home-slider">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner" role="listbox">
                <!-- Slide One - Set the background image for this slide in the line below -->
                <?php if ( have_rows( 'slider' ) ) : 
                    $no =1;
                    ?>
	<?php while ( have_rows( 'slider' ) ) : the_row(); ?>
                <div class="carousel-item <?php if($no == 1){ echo'active';} ?>" style="background-image: url('<?php the_sub_field( 'image' ); ?>'); background-position-y: 119px;">
                    <div class="container">
                        
                    </div>
                </div>
                <?php $no++; endwhile; ?>
<?php else : ?>
	<?php // no rows found ?>
<?php endif; ?>

            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon custom-control" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon custom-control" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
    
<section>


       <!-- WIDE SECTION END -->
        
                 <div class="row">
                    
                    <?php if ( have_rows( 'gallery' ) ) : ?>
			<?php while ( have_rows( 'gallery' ) ) : the_row(); ?>
                    <div class="col-md-6 col-lg-6 layer-counter">
                        <a class="image-popup-vertical-fit" href="<?php the_sub_field( 'image' ); ?>">
                            <div class="image-mask"></div>
                            <img src="<?php the_sub_field( 'image' ); ?>" alt="" />
                        </a>
                    </div>
                    
                    <?php endwhile; ?>
		<?php else : ?>
			<?php // no rows found ?>
		<?php endif; ?>
                
            </div>
        
        
    </section>    
    
    
     <?php endwhile; endif; ?>
    <style>
        .slick-slide{
            height:unset;
        }
        
        .col-md-6.col-lg-6.layer-counter {
    padding: 8px 15px;
}
    </style>

<?php get_footer();?>

