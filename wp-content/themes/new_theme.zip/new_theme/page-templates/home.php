<?php



/**



 Template Name: home



 */



?>

<?php get_header();?>
<?php if (have_posts()) : while ( have_posts() ) : the_post(); ?>
<div class="home-slider">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner" role="listbox">
                <!-- Slide One - Set the background image for this slide in the line below -->
                <?php if ( have_rows( 'slider' ) ) : 
                    $no =1;
                    ?>
	<?php while ( have_rows( 'slider' ) ) : the_row(); ?>
                <div class="carousel-item <?php if($no == 1){ echo'active';} ?>" style="background-image: url('<?php the_sub_field( 'image' ); ?>')">
                    <div class="container">
                        <div class="slider-caption slider-caption-alt">
                            <h2 class="display-4 animated fadeInRight"><span><?php the_sub_field( 'title' ); ?></span></h2>
                            <p class="lead animated fadeInRight"><?php the_sub_field( 'sort_description' ); ?>.</p>
                            <?php if ( have_rows( 'button' ) ) : ?>
			<?php while ( have_rows( 'button' ) ) : the_row(); ?>
                            <div class="btn-more"><a class="btn btn-slider" href="<?php the_sub_field( 'url' ); ?>" role="button"><?php the_sub_field( 'title' ); ?></a></div>
                            <?php endwhile; ?>
		<?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php $no++; endwhile; ?>
<?php else : ?>
	<?php // no rows found ?>
<?php endif; ?>

            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon custom-control" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon custom-control" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
    <!--SLIDER END-->

    <!-- CONTENT START -->
    <section>
        <!-- ABOUT START -->
        <div class="container">
        <?php if ( have_rows( 'section_description' ) ) : ?>
	<?php while ( have_rows( 'section_description' ) ) : the_row(); ?>
            <div class="row">
                <div class="col-lg-6">
                    <div class="og-about">
                        <h5><?php the_sub_field( 'subtitle' ); ?></h5>
                        <h2><?php the_sub_field( 'title' ); ?></h2>
                        <!--<figure class="signature"><img src="<?php the_sub_field( 'logo' ); ?>" alt=""></figure>-->
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="og-info">
                    <?php the_sub_field( 'description' ); ?>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
<?php endif; ?>
            <hr class="section-divider">

            <div class="about-bar">
                <div class="row">
                <?php if ( have_rows( 'section_brand_promise' ) ) : ?>
	<?php while ( have_rows( 'section_brand_promise' ) ) : the_row(); ?>
                    <div class="col-lg-6">
                        <div class="ab-box">
                            <figure class="ab-icon"><img src="<?php the_sub_field( 'icon' ); ?>" alt=""></figure>
                            <div class="ab-caption">
                                <h4><?php the_sub_field( 'title' ); ?></h4>
                                <p><?php the_sub_field( 'description' ); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
<?php else : ?>
	<?php // no rows found ?>
<?php endif; ?>
                </div>
            </div>
        </div>
        <!-- CONTENT END -->

        <!--SERVICES SECTION START-->
        <div class="grid-carousel-container">
            <div class="row">
                <!-- <div class="col-md-3 col-lg-3 layer-counter">
                    <div class="lc-content">
                        <h4>YEARS OF EXPERIENCE</h4>
                        <div class="counter-box">
                            <div class="counter">27</div>
                            <div class="span-plus">+</div>
                        </div>

                    </div>
                </div> -->
                <div class="col-md-12 col-lg-12 carousel-layer">
                    <div class="grid-carousel slider">
                    <?php if ( have_rows( 'section_galery_image' ) ) : ?>
	<?php while ( have_rows( 'section_galery_image' ) ) : the_row(); ?>
                        <div class="slide">
                            <div class="grid-layer">
                                <figure class="gl-thumbnail"><img src="<?php the_sub_field( 'image' ); ?>" alt=""></figure>
                                <div class="gl-caption">
                                    <h2><?php the_sub_field( 'title' ); ?></h2>
                                    <p><?php the_sub_field( 'subtitle' ); ?>    </p>
                                </div>
                                <div class="gl-overlay"></div>
                            </div>
                        </div>
                        <?php endwhile; ?>
<?php else : ?>
	<?php // no rows found ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <!--SERVICES SECTION END-->

        <!-- WIDE SECTION START -->
        <div class="container-wide-grid">
        <?php if ( have_rows( 'section_grid_image' ) ) : ?>
	<?php while ( have_rows( 'section_grid_image' ) ) : the_row(); ?>
            <?php if(get_sub_field( 'position_grid' )=="Left"){ ?>
            <div class="row">
                <div class="col-lg-6 full-thumb-layer" style="background-image:url('<?php the_sub_field( 'image' ); ?>');"></div>
                <div class="col-lg-6 full-caption-layer">
                    <div class="fc-content">
                        <h5><?php the_sub_field( 'title' ); ?></h5>
                        <h2><?php the_sub_field( 'subtitle' ); ?></h2>
                        <p><?php the_sub_field( 'sort_description' ); ?></p>
                        <div class="span-checklist">
                        <?php if ( have_rows( 'list_spesifikasi' ) ) : ?>
			<?php while ( have_rows( 'list_spesifikasi' ) ) : the_row(); ?>
                            <p><?php the_sub_field( 'title' ); ?></p>
                            <?php endwhile; ?>
		<?php else : ?>
			<?php // no rows found ?>
		<?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php }else{ ?>
            <div class="row">
                <div class="order-last order-md-12 col-lg-6 full-caption-layer">
                    <div class="fc-content fc-left-align">
                        <h5><?php the_sub_field( 'title' ); ?></h5>
                        <h2><?php the_sub_field( 'subtitle' ); ?></h2>
                        <p><?php the_sub_field( 'sort_description' ); ?></p>
                        <div class="span-checklist">
                        <?php if ( have_rows( 'list_spesifikasi' ) ) : ?>
			<?php while ( have_rows( 'list_spesifikasi' ) ) : the_row(); ?>
                            <p><?php the_sub_field( 'title' ); ?></p>
                            <?php endwhile; ?>
		<?php else : ?>
			<?php // no rows found ?>
		<?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="order-first order-md-12 col-lg-6 full-thumb-layer-alt" style="background-image:url('<?php the_sub_field( 'image' ); ?>');"></div>
            </div>
            <?php } ?> 
            <?php endwhile; ?>
<?php else : ?>
	<?php // no rows found ?>
<?php endif; ?>
        </div>
        <!-- WIDE SECTION END -->
        <?php if ( have_rows( 'section_product' ) ) : ?>
	<?php while ( have_rows( 'section_product' ) ) : the_row(); ?>
        <div class="project-grid-bg">
            <!-- PROJECT GRID START -->
            <div class="container" style="margin: 1rem auto 1rem auto;">
                <div class="section-title">
                    <h2><?php the_sub_field( 'title' ); ?></h2>
                    <p><?php the_sub_field( 'description' ); ?></p>
                </div>
                <div class="filter-container">
                    <ul class="filter">
                        <li class="active" data-filter="*">All</li>
                        <?php if ( have_rows( 'category_product' ) ) : ?>
			<?php while ( have_rows( 'category_product' ) ) : the_row(); ?>
                        <li data-filter=".<?php echo str_replace(' ', '-', get_sub_field( 'title' )) ; ?>"><?php the_sub_field( 'title' ); ?></li>
                        <?php endwhile; ?>
		<?php else : ?>
			<?php // no rows found ?>
		<?php endif; ?> 
                    </ul>
                </div>
                <div class="grid" id="kehl-grid">
                    <div class="grid-sizer"></div>
                    
                    <?php if ( have_rows( 'list_product' ) ) : ?>
			<?php while ( have_rows( 'list_product' ) ) : the_row(); ?>
                    <div class="grid-box <?php echo str_replace(' ', '-', get_sub_field( 'filter' )) ; ?>">
                        <a class="image-popup-vertical-fit" href="<?php the_sub_field( 'image' ); ?>">
                            <div class="image-mask"></div>
                            <img src="<?php the_sub_field( 'image' ); ?>" alt="" />
                            <h3><?php the_sub_field( 'title' ); ?></h3>
                        </a>
                    </div>
                    
                    <?php endwhile; ?>
		<?php else : ?>
			<?php // no rows found ?>
		<?php endif; ?>
                </div>
            </div>
            <!-- PROJECT GRID END -->
        </div>
        <?php endwhile; ?>
<?php endif; ?>
        <!-- LATEST NEWS START -->
        <?php if ( have_rows( 'section_testimoni' ) ) : ?>
	<?php while ( have_rows( 'section_testimoni' ) ) : the_row(); ?>
        <div class="container" style="display:none;">
            <div class="section-title">
                <h2><?php the_sub_field( 'title' ); ?></h2>
                <p><?php the_sub_field( 'description' ); ?></p>
            </div>
            <div class="row cm-bottom">
                <div class="col-lg-6 testimonial-side">
                    <div id="testimonial-slider" class="owl-carousel oc-testiminial-block">
                    <?php if ( have_rows( 'testimoni' ) ) : ?>
			<?php while ( have_rows( 'testimoni' ) ) : the_row(); ?>
                        <div class="testimonial">
                            <div class="client-avatar">
                                <img src="<?php the_sub_field( 'image' ); ?>" alt="">
                            </div>
                            <div class="testimonial-author">
                                <h3><?php the_sub_field( 'title' ); ?></h3>
                                <p><?php the_sub_field( 'job' ); ?></p>
                            </div>
                            <div class="testimonial-content">
                                <p><?php the_sub_field( 'captions' ); ?>
                                </p>
                            </div>
                        </div>
                        <?php endwhile; ?>
		<?php else : ?>
			<?php // no rows found ?>
		<?php endif; ?>
                    </div>
                </div>
                <?php if ( have_rows( 'colom_about' ) ) : ?>
			<?php while ( have_rows( 'colom_about' ) ) : the_row(); ?>
                <div class="col-lg-6 span-about">
                    <div class="sa-content">
                        <div class="sa-tittle">
                            <h5><?php the_sub_field( 'title' ); ?></h5>
                            <h2><?php the_sub_field( 'subtitle' ); ?></h2>
                        </div>
                        <p><?php the_sub_field( 'description' ); ?></p>
                        <div class="sa-list">
                        <?php if ( have_rows( 'list_spesifikasi' ) ) : ?>
					<?php while ( have_rows( 'list_spesifikasi' ) ) : the_row(); ?>
                            <p><?php the_sub_field( 'title' ); ?></p>
                            <?php endwhile; ?>
				<?php else : ?>
					<?php // no rows found ?>
				<?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
		<?php endif; ?>
            </div>
        </div>
        <?php endwhile; ?>
<?php endif; ?>
        <!-- LATEST NEWS END -->

        <!-- CLIENTS START -->
        <?php if ( have_rows( 'section_brand_logo' ) ) : ?>
	<?php while ( have_rows( 'section_brand_logo' ) ) : the_row(); ?>
        <div class="container-fluid clients-wide-section">
            <div class="container" style="padding-top:35px;">
                <div class="section-title">
                    <h2><?php the_sub_field( 'title' ); ?></h2>
                    <p><?php the_sub_field( 'description' ); ?></p>
                </div>
                <div class="clients-carousel slider">
               <?php if ( have_rows( 'brand_logo' ) ) : ?>
			<?php while ( have_rows( 'brand_logo' ) ) : the_row(); ?>
                    <div class="slide">
                        <figure class="clients-logo"><img src="<?php the_sub_field( 'image' ); ?>" alt=""></figure>
                    </div>
                    <?php endwhile; ?>
<?php else : ?>
	<?php // no rows found ?>
<?php endif; ?>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
<?php endif; ?>
        <!-- CLIENTS END -->

    </section>
    <?php endwhile; endif; ?>
    <style>
        .slick-slide{
            height:unset;
        }
        
        .og-info {
            margin-top:-1rem;
         }
        .og-info p{
            font-size:18px;
        }
        
        
        .carousel-item:before {
            opacity:0.2;
        }
        
        
        @media only screen and (max-width: 576px) {
        .slider-caption.slider-caption-alt h2 {
     font-size: 20px;
    }

  .slider-caption.slider-caption-alt p {
    text-align: center;
    max-width: 100%;
    margin-left: 9%;
   }
        }
        
        
    
        
    </style>

<?php get_footer();?>

