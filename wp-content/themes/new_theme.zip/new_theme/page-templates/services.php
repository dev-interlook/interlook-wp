<?php



/**



 Template Name: Services



 */



?>

<?php get_header();?>

<?php if ( have_rows( 'section_banner' ) ) : ?>
	<?php while ( have_rows( 'section_banner' ) ) : the_row(); ?>
<div class="sections" style="background-image:url(<?php the_sub_field( 'image' ); ?>)">
        <div class="container">
            <div class="pages-title">
                <h1><?php the_sub_field( 'subtitle' ); ?> <br> <span><?php the_sub_field( 'title' ); ?></span></h1>
                <p><a href="/">Home</a> &nbsp; > &nbsp; <a href="#">Services</a></p>
            </div>
        </div>
    </div>
	<?php endwhile; ?>
<?php endif; ?>


<section>
    <!-- SERVICES START -->
    <div class="container">
    <?php if ( have_rows( 'section_project' ) ) : ?>
	<?php while ( have_rows( 'section_project' ) ) : the_row(); ?>
        <div class="section-tittle-alt">
            <h5><?php the_sub_field( 'subtitle' ); ?></h5>
            <h2><?php the_sub_field( 'title' ); ?></h2>
        </div>
        <p class="gallery-info service-alt"><?php the_sub_field( 'description' ); ?></p>
        
        <?php endwhile; endif; ?>

        <div class="row hover-effects image-hover">
        <?php $currentPage = get_query_var('paged'); ?>
<?php $latest = new WP_Query(array('cat' => 4 ,'posts_per_page' => 6, 'paged' => $currentPage));?>
<?php if(have_posts()) :while($latest->have_posts()) : $latest->the_post();?>
          <div class="col-md-6 col-lg-4">
            <div class="service-box">
                <figure class="service-thumbnail"><img src="<?php the_field( 'cover' ); ?>" alt=""></figure> 
                <div class="sb-icon-box">
                    <figure class="sb-icon"><img src="<?php the_field( 'icon' ); ?>" alt=""></figure>
                </div>
                <div class="sb-caption">
                    <h3><?php the_title(); ?></h3>
                    <p><?php the_field( 'sort_description' ); ?></p>
                    <h5><a href="<?php the_permalink() ?>">LEARN MORE</a></h5>
                </div>
            </div>
          </div>

          <?php endwhile; endif; ?>

        </div>
        <div class="site-pagination">
                <nav aria-label="Page navigation example">
                  
                  <?php 


$pages = paginate_links( array(
		'current' => max( 1, get_query_var('paged') ),
		'total' => $latest->max_num_pages,
		'type'  => 'array',
		'prev_next' => true,
		'prev_text' => __('<i class="fas fa-arrow-left"></i>'),
		'next_text' => __('<i class="fas fa-arrow-right"></i>'),
	) );
	if( is_array( $pages ) ) {
		$paged = ( get_query_var('paged') == 0 ) ? 1 : get_query_var('paged');
		echo '<ul class="pagination">';
		foreach ( $pages as $page ) {
				echo '<li class="page-item">'.$page.'</li>';
		}
	   echo '</ul>';
		}

?>
<style>
span.page-numbers.current {
    color: #FFA600;
    
}

li.page-item a {
    color: #000;
}

li.page-item {
    min-width: 40px;
    text-align: center;
}
.site-pagination nav {
    max-width: max-content;
    margin: auto !important;
}
.slick-slide {
    margin-right: 28px;
    margin-left:4px;
}

li.page-item i {
    margin-top: 5px;
}

figure.service-thumbnail {
    height: unset !important;
}

.service-box {
    margin-bottom: 28px;
}

</style>

                </nav>
            </div> 
    </div>
    <!-- SERVICES START -->
    <?php if (have_posts()) : while ( have_posts() ) : the_post(); ?>

    <!-- WHY US START -->
    <?php if ( have_rows( 'section_how_it_work' ) ) : ?>
	<?php while ( have_rows( 'section_how_it_work' ) ) : the_row(); ?>
    <div class="container-fluid wide-banner">
        <div class="wide-banner-content">
            <h5><?php the_sub_field( 'subtitle' ); ?></h5>
            <h2><?php the_sub_field( 'title' ); ?></h2>
            <p><?php the_sub_field( 'description' ); ?></p>
        </div>
    </div>
    <!-- WHY US END -->
    
    <!-- YOUTUBE POPUP START -->
    <div class="container popup-video-section">
        <div class="organic-pulsing-video">
          <div class="youtube-popup" data-listnum="1" style="display: none">
            <a href="<?php the_sub_field( 'url_video' ); ?>" class="popup-youtube">
                <figure class="video-image"><img src="<?php the_sub_field( 'cover_video' ); ?>" alt=""></figure>
            </a>
            <button class="pulse-button"></button>
          </div>
        </div> 
    </div>
    <?php endwhile; ?>
<?php endif; ?>
    <!-- YOUTUBE POPUP END -->
    
    <!-- LATEST NEWS START -->
    <div class="container">
        <div class="section-title">
        <?php if ( have_rows( 'section_latest_news' ) ) : ?>
	<?php while ( have_rows( 'section_latest_news' ) ) : the_row(); ?>
            <h2><?php the_sub_field( 'title' ); ?></h2>
            <p><?php the_sub_field( 'description' ); ?></p>
            <?php endwhile; ?>
<?php endif; ?>
        </div>
        <?php endwhile; endif; ?>
        <div class="news-carousel slider hover-effects image-hover">
        <?php $latest = new WP_Query(array('cat' => 2 , 'showposts' => 6));?>
<?php if(have_posts()) :while($latest->have_posts()) : $latest->the_post();?>
        <div class="slide">
          <div class="post-preview">
                    <figure class="post-preview-img"><a href="<?php the_permalink() ?>"><img src="<?php the_field( 'cover' ); ?>" alt=""></a></figure>
                    <div class="pp-caption">
                        <h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
                        <p><?php the_field( 'sort_content' ); ?></p>
                        <h4 class="link"><a href="<?php the_permalink() ?>">Read More</a></h4>
                        <hr class="post">
                        <div class="pp-bottom">
                        <?php if ( have_rows( 'autor' ) ) : ?>
	<?php while ( have_rows( 'autor' ) ) : the_row(); ?>
                            <div class="about-author">
                                <figure class="author-avatar"><img src="<?php the_sub_field( 'image' ); ?>" alt=""></figure>
                                <div class="author-info">
                                    <h5><?php the_sub_field( 'title' ); ?></h5>
                                    <p><?php the_sub_field( 'Job' ); ?></p>
                                </div>
                            </div>
                            <?php endwhile; ?>
<?php endif; ?>
                            <div class="post-social">
                                <p><?php echo get_the_date(); ?></p>
                                <div class="ps-social-icons"><a href="#"><i class="fab fa-facebook-f"></i></a></div>
                                <div class="ps-social-icons"><a href="#"><i class="fab fa-twitter"></i></a></div>
                                <div class="ps-social-icons"><a href="#"><i class="fab fa-instagram"></i></a></div>
                                <div class="ps-social-icons"><a href="#"><i class="fab fa-google-plus-g"></i></a></div>
                            </div>
                        </div>
                    </div>
                </div>
          </div>

          <?php endwhile; endif; ?>
        </div>
    </div>
    <!-- LATEST NEWS END -->
    <?php if (have_posts()) : while ( have_posts() ) : the_post(); ?>
    <!-- CLIENTS START -->
    <div class="container-fluid clients-wide-section">
        <div class="container">
            <div class="clients-carousel slider">
            <?php if ( have_rows( 'section_partner' ) ) : ?>
	<?php while ( have_rows( 'section_partner' ) ) : the_row(); ?>
              <div class="slide">
                  <figure class="clients-logo"><img src="<?php the_sub_field( 'image' ); ?>" alt=""></figure>
              </div>
              <?php endwhile; ?>
<?php else : ?>
	<?php // no rows found ?>
<?php endif; ?>
            </div>
        </div>
    </div>
    <!-- CLIENTS END -->
    <?php endwhile; endif; ?>
</section> 

<style>
    .slick-slide {
    height: unset;
}
</style>
    <?php get_footer();?>