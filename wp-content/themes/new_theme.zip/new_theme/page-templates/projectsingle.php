<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since Twenty Seventeen 1.0
 * @version 1.0
 */

get_header(); ?>
<div class="sections">
        <div class="container">
            <div class="pages-title">
                <h1>Eksonindo <br> <span><?php the_title(); ?></span></h1>
                <p><a href="/">Home</a> &nbsp; > <a href="/services/">Services</a> &nbsp; > &nbsp; <a href="#"><?php the_title(); ?></a></p>
            </div>
        </div>  
    </div>
    
    
  
    <!-- CONTENT START -->
    <section>
        <div class="container">
            <div class="row">
              <!-- SINGLE POST CONTENT START -->
              <div class="col-lg-12 col-xl-12">
                <figure class="post-image"><img src="<?php the_field( 'cover' ); ?>" alt=""></figure>
                <div class="post-content">
                    <h2><?php the_tItle(); ?></h2>
                    <?php the_field( 'content' ); ?>
                </div>
              </div>
            </div>
        </div>

    </section>
	<style>

a.btn.btn-tags {
    margin-bottom: 5px;
}

	</style>

<?php
get_footer();
