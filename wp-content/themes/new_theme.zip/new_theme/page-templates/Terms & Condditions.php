<?php



/**



 Template Name: Terms & Condditions



 */



?>

<?php get_header();?>

<?php if ( have_rows( 'section_banner' ) ) : ?>
	<?php while ( have_rows( 'section_banner' ) ) : the_row(); ?>
<div class="sections" style="background-image:url(<?php the_sub_field( 'image' ); ?>)">
        <div class="container">
            <div class="pages-title">
                <h1><?php the_sub_field( 'subtitle' ); ?> <br> <span><?php the_sub_field( 'title' ); ?></span></h1>
                <p><a href="/">Home</a> &nbsp; > &nbsp; <a href="#">Terms & Condditions</a></p>
            </div>
        </div>
    </div>
	<?php endwhile; ?>
<?php endif; ?>

<section>
        <!-- FAQ START -->
        <?php if ( have_rows( 'section_how_to_work' ) ) : ?>
	<?php while ( have_rows( 'section_how_to_work' ) ) : the_row(); ?>
        <div class="container">
            <div class="accordion-title">
                <h2><?php the_sub_field( 'title' ); ?></h2>
                <p><?php the_sub_field( 'description' ); ?> </p>
            </div>
            <ul class="accordion">
            <?php if ( have_rows( 'list_how_to_work' ) ) : ?>
			<?php while ( have_rows( 'list_how_to_work' ) ) : the_row(); ?>
                <li>
                    <a><?php the_sub_field( 'title' ); ?></a>
                    <p>	<?php the_sub_field( 'description' ); ?></p>
                </li>
                <?php endwhile; ?>
		<?php else : ?>
			<?php // no rows found ?>
		<?php endif; ?>
            </ul> <!-- / accordion -->
        </div>
        <?php endwhile; ?>
<?php endif; ?>
        <div class="container">
            <div class="row">
            <?php if ( have_rows( 'section_contact' ) ) : ?>
	<?php while ( have_rows( 'section_contact' ) ) : the_row(); ?>
    <?php if ( have_rows( 'contact_us' ) ) : ?>
			<?php while ( have_rows( 'contact_us' ) ) : the_row(); ?>
              <div class="col-lg-4 content-box">
                <a href="#" target="_blank">
                    <div class="icon-circle"><i class="fas fa-phone"></i></div>
                    
                    <h3><?php the_sub_field( 'title' ); ?></h3>
                    <p>	<?php the_sub_field( 'content' ); ?></p>
                    
                </a>
                  <h5><a href="#">Call Us</a></h5>
              </div>
              <?php endwhile; ?>
		<?php endif; ?>
              <?php if ( have_rows( 'need_help' ) ) : ?>
			<?php while ( have_rows( 'need_help' ) ) : the_row(); ?>

              <div class="col-lg-4 content-box middle-box center-box">
                <a href="#" target="_blank">
                    <div class="icon-circle"><i class="fas fa-life-ring"></i></div>
                    <h3><?php the_sub_field( 'title' ); ?></h3>
                    <p>	<?php the_sub_field( 'content' ); ?></p>
                    
                </a>
                <h5><a href="#">Send an Email</a></h5>
              </div>
              <?php endwhile; ?>
		<?php endif; ?>
              <?php if ( have_rows( 'working_hours' ) ) : ?>
			<?php while ( have_rows( 'working_hours' ) ) : the_row(); ?>

              <div class="col-lg-4 content-box">
                <a href="#" target="_blank">
                    <div class="icon-circle"><i class="fas fa-clock"></i></div>
                    <h3><?php the_sub_field( 'title' ); ?></h3>
                    <p>	<?php the_sub_field( 'content' ); ?></p>
                    
                </a>
                <h5><a href="#">Visit Our Office</a></h5>
              </div>
              <?php endwhile; ?>
		<?php endif; ?>

              <?php endwhile; ?>
<?php endif; ?>
            </div>  
        </div>
        <!-- FAQ START -->
    </section> 
    

    <?php get_footer();?>