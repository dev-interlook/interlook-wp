<?php



/**



 Template Name: Our Factory



 */



?>

<?php get_header();?>
<?php if (have_posts()) : while ( have_posts() ) : the_post(); ?>
<div class="home-slider">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner" role="listbox">
                <!-- Slide One - Set the background image for this slide in the line below -->
                <?php if ( have_rows( 'slider' ) ) : 
                    $no =1;
                    ?>
	<?php while ( have_rows( 'slider' ) ) : the_row(); ?>
                <div class="carousel-item <?php if($no == 1){ echo'active';} ?>" style="background-image: url('<?php the_sub_field( 'image' ); ?>')">
                    <div class="container">
                        <div class="slider-caption slider-caption-alt">
                            <h2 class="display-4 animated fadeInRight"><span><?php the_sub_field( 'title' ); ?></span></h2>
                            <p class="lead animated fadeInRight"><?php the_sub_field( 'sort_description' ); ?>.</p>
                            <?php if ( have_rows( 'button' ) ) : ?>
			<?php while ( have_rows( 'button' ) ) : the_row(); ?>
                            <div class="btn-more"><a class="btn btn-slider" href="<?php the_sub_field( 'url' ); ?>" role="button"><?php the_sub_field( 'title' ); ?></a></div>
                            <?php endwhile; ?>
		<?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php $no++; endwhile; ?>
<?php else : ?>
	<?php // no rows found ?>
<?php endif; ?>

            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon custom-control" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon custom-control" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
     <?php endwhile; endif; ?>
    <style>
        .slick-slide{
            height:unset;
        }
        
        
.carousel-item::before{
    display:none;
}
    </style>

<?php get_footer();?>

