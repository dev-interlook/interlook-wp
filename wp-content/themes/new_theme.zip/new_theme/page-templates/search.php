<?php



/**



 Template Name: Search



 */



?>

<?php get_header();?>

<?php if ( have_rows( 'section_banner' ) ) : ?>
	<?php while ( have_rows( 'section_banner' ) ) : the_row(); ?>
<div class="sections" style="background-image:url(<?php the_sub_field( 'image' ); ?>)">
        <div class="container">
            <div class="pages-title">
                <h1><?php the_sub_field( 'subtitle' ); ?> <br> <span> Search : "<?php echo $_POST['search']; ?>"</span></h1>
                <p><a href="/">Home</a> &nbsp; > &nbsp; <a href="#">Search</a></p>
            </div>
        </div>
    </div>
	<?php endwhile; ?>
<?php endif; ?>

<?php  $search = $_POST['search']; ?>
<section>
        <div class="container">
            <!-- BLOG GRID START -->
            <h2>Blog</h2>
            <div class="row">
<?php $latest = new WP_Query(array('cat' => 2 , 's' => $search));?>
<?php if(have_posts()) :while($latest->have_posts()) : $latest->the_post();?>
              <div class="col-md-6 col-lg-6">
                <div class="post-preview">
                    <figure class="post-preview-img"><a href="<?php the_permalink() ?>"><img src="<?php the_field( 'cover' ); ?>" alt=""></a></figure>
                    <div class="pp-caption">
                        <h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
                        <p><?php the_field( 'sort_content' ); ?></p>
                        <h4 class="link"><a href="<?php the_permalink() ?>">Read More</a></h4>
                        <hr class="post">
                        <div class="pp-bottom">
                        <?php if ( have_rows( 'autor' ) ) : ?>
	<?php while ( have_rows( 'autor' ) ) : the_row(); ?>
                            <div class="about-author">
                                <figure class="author-avatar"><img src="<?php the_sub_field( 'image' ); ?>" alt=""></figure>
                                <div class="author-info">
                                    <h5><?php the_sub_field( 'title' ); ?></h5>
                                    <p><?php the_sub_field( 'Job' ); ?></p>
                                </div>
                            </div>
                            <?php endwhile; ?>
<?php endif; ?>
                            <div class="post-social">
                                <p><?php echo get_the_date(); ?></p>
                                <div class="ps-social-icons"><a href="#"><i class="fab fa-facebook-f"></i></a></div>
                                <div class="ps-social-icons"><a href="#"><i class="fab fa-twitter"></i></a></div>
                                <div class="ps-social-icons"><a href="#"><i class="fab fa-instagram"></i></a></div>
                                <div class="ps-social-icons"><a href="#"><i class="fab fa-google-plus-g"></i></a></div>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
              <?php endwhile; endif; ?>
                </div>
              </div>
            </div>
             
        </div>
        <!-- BLOG GRID END -->
    </section>
    <section>
    <!-- SERVICES START -->
    <div class="container">
    <h2>Project</h2>
    <div class="row hover-effects image-hover">
        
<?php $latest = new WP_Query(array('cat' => 4, 's' => $search));?>
<?php if(have_posts()) :while($latest->have_posts()) : $latest->the_post();?>
          <div class="col-md-6 col-lg-4">
            <div class="service-box">
                <figure class="service-thumbnail"><img src="<?php the_field( 'cover' ); ?>" alt=""></figure> 
                <div class="sb-icon-box">
                    <figure class="sb-icon"><img src="<?php the_field( 'icon' ); ?>" alt=""></figure>
                </div>
                <div class="sb-caption">
                    <h3><?php the_title(); ?></h3>
                    <p><?php the_field( 'sort_description' ); ?></p>
                    <h5><a href="#">LEARN MORE</a></h5>
                </div>
            </div>
          </div>

          <?php endwhile; endif; ?>

        </div>
    </div>
    <style>
    .image-hover .service-thumbnail{
        height:unset;
    }
    </style>
</section>
<section>
    <div class="container">
        
        <h2>Product</h2>
        
        <!-- PROJECT GRID START -->
        <div class="row  image-hover">
<?php $latest = new WP_Query(array('cat' => 3 , 's' => $search));?>
<?php if(have_posts()) :while($latest->have_posts()) : $latest->the_post();?>
          <div class="col-md-6 col-lg-4">
             <div class="project-grid">
                <figure class="pg-thumbnail"><a href="<?php the_permalink() ?>"><img src="<?php the_field( 'cover' ); ?>" alt=""></a></figure> 
                <div class="card-product">
                    <h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a</h3>
                 </div>
             </div>
          </div>
          <?php endwhile; endif; ?>
        </div>
        
        <!-- PROJECT GRID END -->
    </div>
    <style>
        .card-product>h3>a {
    color: #000;
}

.card-product {
    margin-top: -21px;
}
    </style>
</section>

    <?php get_footer();?>