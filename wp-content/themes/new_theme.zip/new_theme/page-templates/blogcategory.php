<?php



/**



 Template Name: blogcategory



 */



?>

<div class="sections" style="background:url(/wp-content/uploads/2021/12/innovation_lab-1.jpg)">
        <div class="container">
            <div class="pages-title">
                <h1>Eksonindo <br> <span><?php echo single_cat_title(); ?></span></h1>
                <p><a href="/">Home</a> &nbsp; > <a href="/blog/">Blog</a> &nbsp; > &nbsp; <a href="#"><?php echo single_cat_title(); ?></a></p>
            </div>
        </div>  
    </div>
    
<section>
        <div class="container">
            <!-- BLOG GRID START -->
            <div class="row">
<?php $latest = new WP_Query(array('cat' => get_queried_object()->term_id ));?>
<?php if(have_posts()) :while($latest->have_posts()) : $latest->the_post();?>
              <div class="col-md-6 col-lg-6">
                <div class="post-preview">
                    <figure class="post-preview-img"><a href="<?php the_permalink() ?>"><img src="<?php the_field( 'cover' ); ?>" alt=""></a></figure>
                    <div class="pp-caption">
                        <h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
                        <p><?php the_field( 'sort_content' ); ?></p>
                        <h4 class="link"><a href="<?php the_permalink() ?>">Read More</a></h4>
                        <hr class="post">
                        <div class="pp-bottom">
                        <?php if ( have_rows( 'autor' ) ) : ?>
	<?php while ( have_rows( 'autor' ) ) : the_row(); ?>
                            <div class="about-author">
                                <figure class="author-avatar"><img src="<?php the_sub_field( 'image' ); ?>" alt=""></figure>
                                <div class="author-info">
                                    <h5><?php the_sub_field( 'title' ); ?></h5>
                                    <p><?php the_sub_field( 'Job' ); ?></p>
                                </div>
                            </div>
                            <?php endwhile; ?>
<?php endif; ?>
                            <div class="post-social">
                                <p><?php echo get_the_date(); ?></p>
                                <div class="ps-social-icons"><a href="#"><i class="fab fa-facebook-f"></i></a></div>
                                <div class="ps-social-icons"><a href="#"><i class="fab fa-twitter"></i></a></div>
                                <div class="ps-social-icons"><a href="#"><i class="fab fa-instagram"></i></a></div>
                                <div class="ps-social-icons"><a href="#"><i class="fab fa-google-plus-g"></i></a></div>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
              <?php endwhile; endif; ?>
                </div>
              
            </div>
             
        <!-- BLOG GRID END -->
    </section>

<style>
span.page-numbers.current {
    color: #FFA600;
    
}

li.page-item a {
    color: #000;
}

li.page-item {
    min-width: 40px;
    text-align: center;
}
.site-pagination nav {
    max-width: max-content;
    margin: auto !important;
}

.site-pagination {
    margin-top: -55px;
}

li.page-item i {
    margin-top: 5px;
}

figure.post-preview-img {
    max-height: 430px;
    overflow: hidden;
}

section {
    min-height: 1740px;
}

</style>
