<?php



/**



 Template Name: blogcategory



 */


if (in_category('18')) {
$background = get_field( 'banner_product_eiger', 'option' );
}
else if (in_category('17')) {
$background = get_field( 'banner_product_bodypack', 'option' );
}
else if (in_category('19')) { 
$background = get_field( 'banner_product_exsport', 'option' );
}
else if (in_category('25')) { 
$background = get_field( 'banner_product_garmen', 'option' );
}

?>


<div class="sections" style="background-image: url(<?php echo $background; ?>);">
        <div class="container">
            <div class="pages-title">
                <h1>Eksonindo <br> <span><?php echo single_cat_title(); ?></span></h1>
                <p><a href="/">Home</a> &nbsp; > <a href="/product/">Product</a> &nbsp; > &nbsp; <a href="#"><?php echo single_cat_title(); ?></a></p>
            </div>
        </div>  
    </div>
    
<section>
        <div class="container">
            <!-- BLOG GRID START -->
            <div class="row">
<?php $latest = new WP_Query(array('cat' => get_queried_object()->term_id, 'orderby' => 'title', 'order' => 'ASC'));?>
<?php if(have_posts()) :while($latest->have_posts()) : $latest->the_post();?>
              <div class="col-md-6 col-lg-4">
                <div class="project-grid">
                    <figure class="pg-thumbnail"><a href="<?php the_permalink() ?>"><img src="<?php the_field( 'cover' ); ?>" alt=""></a></figure>
                    <div class="card-product">
                        <h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
                    </div>
                </div>
              </div>
              <?php endwhile; endif; ?>
                </div>
              </div>
            <style>
span.page-numbers.current {
    color: #FFA600;
    
}

li.page-item a {
    color: #000;
}

li.page-item {
    min-width: 40px;
    text-align: center;
}
.site-pagination nav {
    max-width: max-content;
    margin: auto !important;
}

.site-pagination {
    margin-top: -55px;
}

li.page-item i {
    margin-top: 5px;
}

figure.pg-thumbnail img {
    width: 100%;
   
    object-fit: cover !important;
}

.card-product h3 > a:hover {
    color: #EEC344;
}

.card-product h3 > a {
    color: #000;
}

.card-product h3 {
    text-align: center;
    margin-top: 14px;
}

 @media only screen and (max-width: 578px) {
     
     .card-product h3 > a {
    font-size: 21px;
    color: #000;
    }
    
    
 }


</style>
        <!-- BLOG GRID END -->
    </section>
   