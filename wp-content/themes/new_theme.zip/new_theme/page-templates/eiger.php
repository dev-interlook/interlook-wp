<?php



/**



 Template Name: Eiger



 */



?>

<?php get_header();?>
<?php if (have_posts()) : while ( have_posts() ) : the_post(); ?>
<div class="home-slider">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner" role="listbox">
                <!-- Slide One - Set the background image for this slide in the line below -->
                <?php if ( have_rows( 'slider' ) ) : 
                    $no =1;
                    ?>
	<?php while ( have_rows( 'slider' ) ) : the_row(); ?>
                <div class="carousel-item <?php if($no == 1){ echo'active';} ?>" style="background-image: url('<?php the_sub_field( 'image' ); ?>'); background-position-y: -99px;">
                    <div class="container">
                        
                    </div>
                </div>
                <?php $no++; endwhile; ?>
<?php else : ?>
	<?php // no rows found ?>
<?php endif; ?>

            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon custom-control" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon custom-control" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
 
 <section class="p-0 wow fadeIn" id="vimi" style="visibility: visible; animation-name: fadeIn;">
            <div class="container-fluid">
                <div class="row">   
                
                <?php if ( have_rows( 'visi_misi' ) ) : ?>
	<?php while ( have_rows( 'visi_misi' ) ) : the_row(); ?>
                    <!-- start features item -->
                                            <div class="col-12 col-lg-6 col-md-6 p-0 align-items-center cover-1 cover-background position-relative sm-height-300px wow fadeIn" style="background: linear-gradient(rgba(0, 0, 0, 0.45), rgba(0, 0, 0, 0.45)), url(<?php the_sub_field( 'background' ); ?>); margin: 0px auto; visibility: visible; animation-name: fadeIn; background-size: 100% auto; background-position-y: -69px;">
                                            <div class="col-lg-5 vimi">
                            <h5><b><?php the_sub_field( 'title' ); ?></b></h5>
                            <p><?php the_sub_field( 'description' ); ?></p>
                        </div>
                    </div>
                                                    <!-- end features item -->
            <?php endwhile; ?>
<?php else : ?>
	<?php // no rows found ?>
<?php endif; ?>
                    
                    
                </div>
            </div>
            
            <div class="grid" id="kehl-grid">

                    <div class="grid-sizer"></div>

                    <?php if ( have_rows( 'gallery' ) ) : ?>

			<?php while ( have_rows( 'gallery' ) ) : the_row(); ?>

                    <div class="grid-box <?php the_sub_field( 'filter' ); ?>">

                        <a class="image-popup-vertical-fit" href="<?php the_sub_field( 'image' ); ?>">

                            <div class="image-mask"></div>

                            <img src="<?php the_sub_field( 'image' ); ?>" alt="" />
                            <h3><?php the_sub_field( 'title' ); ?></h3>

                        </a>

                    </div>

                    <?php endwhile; ?>

		<?php else : ?>

			<?php // no rows found ?>

		<?php endif; ?>

                </div>
            
            
        </section>
    
    
     <?php endwhile; endif; ?>
    <style>
        .slick-slide{
            height:unset;
        }
        
        .col-md-6.col-lg-6.layer-counter {
    padding: 8px 15px;
}

.vimi p {
    font-size: 18px !important;
    color:#fff;
}

h5 {font-size:32px; line-height:40px; color:#fff;}

.grid-sizer, .grid-box {
    width: 25%;
}

.grid-box img {
    display: block;
    width: auto;
    height: 373px;
}

.container, .container-fluid {
    margin: 7px auto 7px auto;
}

    </style>

<?php get_footer();?>

