<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since Twenty Seventeen 1.0
 * @version 1.0
 */

get_header(); ?>
<div class="sections" style="background:url(/wp-content/uploads/2021/12/SML03133.jpg);">
        <div class="container">
            <div class="pages-title">
                <h1>Eksonindo <br> <span><?php the_title(); ?></span></h1>
                <p><a href="/">Beranda</a> &nbsp; > <a href="/career/">career</a> &nbsp; > &nbsp; <a href="#"><?php the_title(); ?></a></p>
            </div>
        </div>  
    </div>
    
    
  
    <!-- CONTENT START -->
    <section>
        <div class="container">
            <div class="row">
              <!-- SINGLE POST CONTENT START -->
              <div class="col-lg-12 col-xl-12">
                <div class="post-content">
                    <h2><?php the_tItle(); ?></h2>
                    <?php the_content(); ?>
                    <h2>Apply Job</h2>
                    <br><br>
                    <?php echo do_shortcode( '[contact-form-7 id="1047" title="apply job"]' ); ?>
                </div>
              </div>
            </div>
        </div>

    </section>
	<style>

a.btn.btn-tags {
    margin-bottom: 5px;
}

.awsm-job-form-group label {
    font-size: 15px;
    font-weight: 300;
    font-family: 'Poppins', sans-serif;
}

input[type="text"], input[type="email"], textarea,input[type="file"] {
    
    width: 100%;
    margin-top:20px;
        background: #F7FAFA;
    min-height: 60px;
    padding: 6px 12px;
    font-size: 15px;
    border: solid 1px #F7FAFA;
    font-family: 'Poppins', sans-serif;
    color: #000;
}

input[type="submit"] {
    display: block;
        color: #EEC344;
    transition: 0.9s;
    padding: 0.3rem 1.125rem;
    font-size: 0.60rem;
    background: transparent;
    border: solid 2px #FFA600;
    font-family: 'Poppins', sans-serif;
}
.wpcf7 form .wpcf7-response-output {
    font-size: 14px;
}

input[type="submit"] {
    display: block;
    color: #EEC344;
    transition: 0.9s;
    padding: 0.3rem 1.125rem;
    font-size: 0.60rem;
    background: transparent;
    width: 100%;
    border: solid 2px #FFA600;
    font-size: 18px;
    text-transform: uppercase;
}


form.wpcf7-form {
    margin-top: -64px;
}

.top-header {
    height: 70px;
}

input.form-control {
    margin-top: 0px;
}

	</style>

<?php
get_footer();
