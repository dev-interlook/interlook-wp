<?php get_header();?>
<?php
if (in_category('4')) {include (TEMPLATEPATH . '/page-templates/projectsingle.php');
}else if (in_category('5')) {include (TEMPLATEPATH . '/page-templates/blogcategory.php');
}
else if (in_category('6')) {include (TEMPLATEPATH . '/page-templates/blogcategory.php');
}
else if (in_category('7')) {include (TEMPLATEPATH . '/page-templates/blogcategory.php');
}
else if (in_category('17')) {include (TEMPLATEPATH . '/page-templates/productcategory.php');
}
else if (in_category('18')) {include (TEMPLATEPATH . '/page-templates/productcategory.php');
}
else if (in_category('19')) {include (TEMPLATEPATH . '/page-templates/productcategory.php');
}
else if (in_category('25')) {include (TEMPLATEPATH . '/page-templates/productcategory.php');
}

?>
 <?php get_footer();?>