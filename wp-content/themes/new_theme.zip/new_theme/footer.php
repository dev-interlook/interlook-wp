 <!-- Footer -->
 <footer class="main-footer dark">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 mb-30">
                        <div class="item fotcont">
                            <div class="fothead">
                                <h6>Phone</h6>
                            </div>
                            <p>+1 203-123-0606</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-30">
                        <div class="item fotcont">
                            <div class="fothead">
                                <h6>Email</h6>
                            </div>
                            <p>architecture@bauen.com</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-30">
                        <div class="item fotcont">
                            <div class="fothead">
                                <h6>Our Address</h6>
                            </div>
                            <p>24 King St, Charleston, SC 29401 USA</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="sub-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="text-left">
                                <p>© 2022 Bauen. All right reserved.</p>
                            </div>
                        </div>
                        <div class="col-md-4 abot">
                            <div class="social-icon"> <a href="index.html"><i class="ti-facebook"></i></a> <a href="index.html"><i class="ti-twitter"></i></a> <a href="index.html"><i class="ti-instagram"></i></a> <a href="index.html"><i class="ti-pinterest"></i></a> </div>
                        </div>
                        <div class="col-md-4">
                            <p class="right"><a href="#">Terms &amp; Conditions</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <!-- jQuery -->
    <script src="<?php echo get_template_directory_uri(); ?>js/jquery-3.5.1.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>js/jquery-migrate-3.0.0.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>js/modernizr-2.6.2.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>js/imagesloaded.pkgd.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>js/jquery.isotope.v3.0.2.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>js/pace.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>js/popper.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>js/bootstrap.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>js/scrollIt.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>js/jquery.waypoints.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>s/owl.carousel.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>js/jquery.stellar.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>js/jquery.magnific-popup.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>js/YouTubePopUp.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>js/custom.js"></script>
    <?php wp_footer();?>
</body>
</html>