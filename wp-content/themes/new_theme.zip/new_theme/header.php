<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>B A U E N</title>
    <link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/img/favicon.png" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/plugins.css"  />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/style.css" />
    <script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script>
    <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-144098545-1"></script>
    <?php wp_head();?>
</head>

<body>
    <!-- Preloader -->
    <!-- <div id="preloader"></div> -->
    <!-- Progress scroll totop -->
    <div class="progress-wrap cursor-pointer">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="container">
        <!-- Logo -->
        <a class="logo" href="index.html"> <img src="<?php echo get_template_directory_uri(); ?>img/logo.png" alt=""> </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="icon-bar"><i class="ti-line-double"></i></span> </button>
        <!-- Navbar links -->
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a class="nav-link active" href="#" data-scroll-nav="0">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#" data-scroll-nav="1">About</a></li>
                <li class="nav-item"><a class="nav-link" href="#" data-scroll-nav="2">Projects</a></li>
                <li class="nav-item"><a class="nav-link" href="#" data-scroll-nav="3">Services</a></li>
                <li class="nav-item"><a class="nav-link" href="#" data-scroll-nav="4">Blog</a></li>
                <li class="nav-item"><a class="nav-link" href="#" data-scroll-nav="5">Contact</a></li>
            </ul>
        </div>
        </div>
    </nav>
    <!-- Slider -->
    <header id="home" class="header slider-fade" data-scroll-index="0">
        <div class="owl-carousel owl-theme">
            <!-- The opacity on the image is made with "data-overlay-dark="number". You can change it using the numbers 0-9. -->
            <div class="text-left item bg-img" data-overlay-dark="3" data-background="<?php echo get_template_directory_uri(); ?>img/slider/1.jpg">
                <div class="v-middle caption mt-30">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7">
                                    <h1>Innovate Desing in Toronto</h1>
                                    <p>Architecture viverra tellus nec massa dictum the euismoe.
                                        <br>Curabitur viverra the posuere aukue velit.
                                    </p>
                                    <div class="butn-light mt-30 mb-30">
                                        <a href="https://1.envato.market/mDnXD" target="_blank"><span>Buy Now</span></a>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-left item bg-img" data-overlay-dark="4" data-background="<?php echo get_template_directory_uri(); ?>img/slider/2.jpg">
                <div class="v-middle caption mt-30">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7">
                                    <h1>Innovate Desing in Canada</h1>
                                    <p>Architecture viverra tellus nec massa dictum the euismoe.
                                        <br>Curabitur viverra the posuere aukue velit.
                                    </p>
                                    <div class="butn-light mt-30 mb-30">
                                        <a href="https://1.envato.market/mDnXD" target="_blank"><span>Buy Now</span></a>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
  