<?php
if (in_category('4')) {include (TEMPLATEPATH . '/page-templates/projectsingle.php');
}else if (in_category('3')) {include (TEMPLATEPATH . '/page-templates/detailproduct.php');
}else if (in_category('2')) {include (TEMPLATEPATH . '/page-templates/blogsingle.php');
}else{
    include (TEMPLATEPATH . '/page-templates/singlecareer.php');
}



?>